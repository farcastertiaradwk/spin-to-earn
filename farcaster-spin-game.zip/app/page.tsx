"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Flame, Trophy, AlertTriangle } from "lucide-react"
import { SpinWheel } from "@/components/spin-wheel"
import { WalletConnect } from "@/components/wallet-connect"
import { useWallet } from "@/hooks/use-wallet"
import { useSwitchChain } from "wagmi"
import { base } from "wagmi/chains"

export default function HomePage() {
  const { isConnected, address, farcasterFid, connectFarcaster, isFullyConnected, isOnCorrectNetwork, chain } =
    useWallet()

  const { switchChain } = useSwitchChain()
  const [points, setPoints] = useState(0)
  const [isSpinning, setIsSpinning] = useState(false)
  const [lastResult, setLastResult] = useState<string | null>(null)

  const handleSpin = async () => {
    if (!isFullyConnected) {
      alert("Please connect both your wallet and Farcaster account!")
      return
    }

    if (!isOnCorrectNetwork) {
      alert("Please switch to Base network!")
      return
    }

    setIsSpinning(true)
    setLastResult(null)

    try {
      const response = await fetch("/api/spin", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          address: address,
          fid: farcasterFid,
          chainId: chain?.id,
        }),
      })

      const result = await response.json()

      setTimeout(() => {
        setLastResult(result.prize)
        if (result.prize !== "zonk") {
          setPoints((prev) => prev + result.points)
        }
        setIsSpinning(false)
      }, 3000)
    } catch (error) {
      console.error("Spin error:", error)
      setIsSpinning(false)
    }
  }

  const handleSwitchNetwork = () => {
    switchChain({ chainId: base.id })
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-900 via-blue-800 to-blue-600 p-4">
      <div className="max-w-md mx-auto space-y-6">
        {/* Header */}
        <Card className="bg-blue-800/50 border-blue-400 backdrop-blur-sm">
          <CardHeader className="text-center pb-4">
            <div className="flex items-center justify-center gap-2 mb-2">
              <Flame className="w-8 h-8 text-blue-400" />
              <CardTitle className="text-2xl font-bold text-white">DEGEN Spin Game</CardTitle>
            </div>
            <p className="text-blue-200 text-sm">Spin to win DEGEN tokens on Base network!</p>
          </CardHeader>
        </Card>

        {/* Wallet Status */}
        <Card className="bg-blue-800/50 border-blue-400 backdrop-blur-sm">
          <CardContent className="pt-6 space-y-4">
            <WalletConnect />

            {/* Farcaster Connection */}
            {isConnected && !farcasterFid && (
              <Button onClick={connectFarcaster} className="w-full bg-purple-600 hover:bg-purple-700 text-white">
                <Flame className="w-5 h-5 mr-2" />
                Connect Farcaster
              </Button>
            )}

            {/* Network Warning */}
            {isConnected && !isOnCorrectNetwork && (
              <div className="bg-yellow-500/20 border border-yellow-400 rounded-lg p-3">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-5 h-5 text-yellow-400" />
                  <span className="text-yellow-400 font-semibold">Wrong Network</span>
                </div>
                <p className="text-yellow-200 text-sm mb-3">Please switch to Base network to play the game.</p>
                <Button
                  onClick={handleSwitchNetwork}
                  size="sm"
                  className="bg-yellow-600 hover:bg-yellow-700 text-white"
                >
                  Switch to Base
                </Button>
              </div>
            )}

            {/* Connection Status */}
            {isFullyConnected && (
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Trophy className="w-5 h-5 text-yellow-400" />
                    <span className="text-white font-semibold">{points} Points</span>
                  </div>
                  <div className="flex gap-2">
                    <Badge variant="secondary" className="bg-blue-600 text-blue-100">
                      Wallet ✓
                    </Badge>
                    <Badge variant="secondary" className="bg-purple-600 text-purple-100">
                      Farcaster ✓
                    </Badge>
                  </div>
                </div>
                {farcasterFid && <p className="text-blue-200 text-xs">Farcaster ID: {farcasterFid}</p>}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Spin Wheel */}
        <Card className="bg-blue-800/50 border-blue-400 backdrop-blur-sm">
          <CardContent className="pt-6">
            <SpinWheel isSpinning={isSpinning} />

            <div className="mt-6 text-center">
              <Button
                onClick={handleSpin}
                disabled={!isConnected || isSpinning}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg transition-all duration-200 transform hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
              >
                {isSpinning ? (
                  <div className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    Spinning...
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <Flame className="w-5 h-5" />
                    Spin to Win!
                  </div>
                )}
              </Button>
            </div>

            {lastResult && (
              <div className="mt-4 text-center">
                <div
                  className={`p-4 rounded-lg ${
                    lastResult === "zonk"
                      ? "bg-red-500/20 border border-red-400"
                      : "bg-green-500/20 border border-green-400"
                  }`}
                >
                  <p className="text-white font-semibold">
                    {lastResult === "zonk" ? "😔 Try Again!" : `🎉 You won ${lastResult}!`}
                  </p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Game Rules */}
        <Card className="bg-blue-800/50 border-blue-400 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-white text-lg">Game Rules</CardTitle>
          </CardHeader>
          <CardContent className="text-blue-200 text-sm space-y-2">
            <p>• Connect your wallet (MetaMask or Coinbase Wallet)</p>
            <p>• Connect your Farcaster account to play</p>
            <p>• Spin the wheel to win DEGEN tokens or points</p>
            <p>• Most spins result in "zonk" - keep trying!</p>
            <p>• Prizes are sent to your wallet on Base network</p>
            <p>• Transaction fees paid in ETH on Base</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
