import type React from "react"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import "./globals.css"
import Script from "next/script"
import { Providers } from "@/components/providers"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "DEGEN Spin Game - Farcaster Mini App",
  description: "Spin to win DEGEN tokens on Base network!",
  openGraph: {
    title: "DEGEN Spin Game",
    description: "Spin to win DEGEN tokens on Base network!",
    images: ["/api/image"],
  },
  other: {
    "fc:frame": "vNext",
    "fc:frame:image": "/api/image",
    "fc:frame:button:1": "🎰 Spin to Win!",
    "fc:frame:post_url": "/api/spin",
  },
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <Providers>{children}</Providers>
        <Script src="https://unpkg.com/@farcaster/auth-kit@latest/dist/auth-kit.js" strategy="beforeInteractive" />
        <Script id="farcaster-sdk" strategy="beforeInteractive">
          {`
            if (typeof window !== 'undefined') {
              window.farcaster = window.farcaster || {
                on: function(event, callback) {
                  this.events = this.events || {};
                  this.events[event] = this.events[event] || [];
                  this.events[event].push(callback);
                },
                emit: function(event, data) {
                  if (this.events && this.events[event]) {
                    this.events[event].forEach(callback => callback(data));
                  }
                },
                requestAccounts: async function() {
                  const mockData = {
                    address: '0x' + Math.random().toString(16).substr(2, 40),
                    fid: Math.floor(Math.random() * 100000)
                  };
                  this.emit('connect', mockData);
                  return [mockData.address];
                }
              };
            }
          `}
        </Script>
      </body>
    </html>
  )
}
