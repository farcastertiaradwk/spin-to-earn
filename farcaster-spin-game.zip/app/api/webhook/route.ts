import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()

    // Handle Farcaster frame interactions
    console.log("Farcaster webhook received:", body)

    // Return frame response
    return NextResponse.json({
      type: "frame",
      frameUrl: `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/app`,
    })
  } catch (error) {
    console.error("Webhook error:", error)
    return NextResponse.json({ error: "Webhook processing failed" }, { status: 500 })
  }
}
