import { type NextRequest, NextResponse } from "next/server"

const RECIPIENT_WALLET = "0xCC5552a28C2AA0AaE2B09826311900b466AebA65"

// Prize probabilities (heavily weighted towards zonk)
const PRIZES = [
  { type: "zonk", probability: 70, points: 0, degen: 0 },
  { type: "50 Points", probability: 15, points: 50, degen: 0 },
  { type: "10 DEGEN", probability: 8, points: 0, degen: 10 },
  { type: "100 Points", probability: 5, points: 100, degen: 0 },
  { type: "25 DEGEN", probability: 2, points: 0, degen: 25 },
]

function getRandomPrize() {
  const random = Math.random() * 100
  let cumulative = 0

  for (const prize of PRIZES) {
    cumulative += prize.probability
    if (random <= cumulative) {
      return prize
    }
  }

  return PRIZES[0] // fallback to zonk
}

export async function POST(request: NextRequest) {
  try {
    const { address, fid, chainId } = await request.json()

    if (!address || !fid) {
      return NextResponse.json({ error: "Address and FID required" }, { status: 400 })
    }

    if (chainId !== 8453) {
      return NextResponse.json({ error: "Please switch to Base network" }, { status: 400 })
    }

    // Get random prize
    const prize = getRandomPrize()

    // Log the spin attempt
    console.log(`Spin attempt - FID: ${fid}, Address: ${address}, Prize: ${prize.type}`)

    let transactionHash = null

    // If won DEGEN tokens, initiate transfer
    if (prize.degen > 0) {
      try {
        const transferResponse = await fetch(
          `${process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000"}/api/transfer-degen`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              amount: prize.degen,
              winnerAddress: address,
            }),
          },
        )

        const transferResult = await transferResponse.json()

        if (transferResult.success) {
          transactionHash = transferResult.transactionHash
          console.log(`DEGEN transfer successful: ${transactionHash}`)
        }
      } catch (transferError) {
        console.error("DEGEN transfer failed:", transferError)
        // Continue with the game even if transfer fails
      }
    }

    return NextResponse.json({
      success: true,
      prize: prize.type,
      points: prize.points,
      degen: prize.degen,
      transactionHash,
      network: "Base",
      recipient: RECIPIENT_WALLET,
    })
  } catch (error) {
    console.error("Spin API error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
