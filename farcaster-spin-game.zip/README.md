# DEGEN Spin Game - Farcaster Mini App

🎰 Spin to win DEGEN tokens on Base network!

## Features

- 🔥 Farcaster Mini App integration
- 🎯 Spin wheel game with DEGEN token rewards
- 💎 Wagmi wallet connection (MetaMask & Coinbase Wallet)
- ⚡ Base network support
- 🎨 Blue fire theme design

## Supported Wallets

- **MetaMask** - Browser extension wallet
- **Coinbase Wallet** - Mobile and web wallet

## Quick Deploy to Vercel

1. **Clone & Push to GitHub**
\`\`\`bash
git clone <your-repo>
cd farcaster-spin-game
git push origin main
\`\`\`

2. **Deploy to Vercel**
- Connect your GitHub repo to Vercel
- Set environment variables:
  \`\`\`
  NEXT_PUBLIC_BASE_URL=https://your-domain.vercel.app
  RECIPIENT_WALLET=0xCC5552a28C2AA0AaE2B09826311900b466AebA65
  PRIVATE_KEY=your-private-key-for-transactions
  \`\`\`

3. **Configure Farcaster**
- Update `public/farcaster.json` with your domain
- Test the mini app in Farcaster

## Game Rules

- Connect MetaMask or Coinbase Wallet
- Connect Farcaster account
- Spin wheel to win DEGEN tokens or points
- 70% chance of "zonk" (no prize)
- Prizes sent to recipient wallet on Base network
- Transaction fees paid in ETH

## Development

\`\`\`bash
npm install
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000)

## Tech Stack

- Next.js 14 (App Router)
- Wagmi + Viem (Web3)
- Tailwind CSS
- Farcaster SDK
- Base Network
