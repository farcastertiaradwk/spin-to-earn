"use client"

import { useAccount, useDisconnect } from "wagmi"
import { useEffect, useState } from "react"

export function useWallet() {
  const { address, isConnected, chain } = useAccount()
  const { disconnect } = useDisconnect()
  const [farcasterFid, setFarcasterFid] = useState<string | null>(null)

  useEffect(() => {
    // Check for saved Farcaster FID
    const savedFid = localStorage.getItem("farcaster_fid")
    if (savedFid) {
      setFarcasterFid(savedFid)
    }

    // Listen for Farcaster SDK events
    if (typeof window !== "undefined" && (window as any).farcaster) {
      ;(window as any).farcaster.on("connect", (data: any) => {
        setFarcasterFid(data.fid.toString())
        localStorage.setItem("farcaster_fid", data.fid.toString())
      })
      ;(window as any).farcaster.on("disconnect", () => {
        setFarcasterFid(null)
        localStorage.removeItem("farcaster_fid")
      })
    }
  }, [])

  const connectFarcaster = async () => {
    try {
      if (typeof window !== "undefined" && (window as any).farcaster) {
        await (window as any).farcaster.requestAccounts()
      } else {
        // Fallback for development/testing
        const mockFid = Math.floor(Math.random() * 100000)
        setFarcasterFid(mockFid.toString())
        localStorage.setItem("farcaster_fid", mockFid.toString())
      }
    } catch (error) {
      console.error("Failed to connect Farcaster:", error)
    }
  }

  const disconnectAll = () => {
    disconnect()
    setFarcasterFid(null)
    localStorage.removeItem("farcaster_fid")
  }

  return {
    // Wagmi wallet connection
    isConnected,
    address,
    chain,
    disconnect: disconnectAll,

    // Farcaster connection
    farcasterFid,
    connectFarcaster,

    // Combined status
    isFullyConnected: isConnected && !!farcasterFid,
    isOnCorrectNetwork: chain?.id === 8453, // Base mainnet
  }
}
