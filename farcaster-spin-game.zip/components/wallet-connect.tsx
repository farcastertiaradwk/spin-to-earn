"use client"

import { Button } from "@/components/ui/button"
import { Wallet, LogOut, ChevronDown } from "lucide-react"
import { useAccount, useConnect, useDisconnect, useEnsName } from "wagmi"
import { useState } from "react"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"

export function WalletConnect() {
  const { address, isConnected, chain } = useAccount()
  const { data: ensName } = useEnsName({ address })
  const { connect, connectors, isPending } = useConnect()
  const { disconnect } = useDisconnect()
  const [isOpen, setIsOpen] = useState(false)

  const formatAddress = (addr: string) => {
    return `${addr.slice(0, 6)}...${addr.slice(-4)}`
  }

  const getConnectorIcon = (connectorName: string) => {
    switch (connectorName) {
      case "Coinbase Wallet":
        return "🔵"
      case "Injected":
        return "🦊"
      default:
        return "💼"
    }
  }

  const getConnectorDisplayName = (connectorName: string) => {
    switch (connectorName) {
      case "Injected":
        return "MetaMask"
      default:
        return connectorName
    }
  }

  if (isConnected && address) {
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Wallet className="w-5 h-5 text-blue-400" />
            <span className="text-white font-mono text-sm">{ensName || formatAddress(address)}</span>
          </div>
          <Button
            onClick={() => disconnect()}
            variant="outline"
            size="sm"
            className="bg-transparent border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-white"
          >
            <LogOut className="w-4 h-4" />
          </Button>
        </div>

        {chain && (
          <div className="flex items-center gap-2">
            <Badge
              variant="secondary"
              className={`text-xs ${chain.id === 8453 ? "bg-blue-600 text-blue-100" : "bg-yellow-600 text-yellow-100"}`}
            >
              {chain.name}
            </Badge>
            {chain.id !== 8453 && <span className="text-yellow-400 text-xs">⚠️ Switch to Base network</span>}
          </div>
        )}
      </div>
    )
  }

  return (
    <DropdownMenu open={isOpen} onOpenChange={setIsOpen}>
      <DropdownMenuTrigger asChild>
        <Button className="w-full bg-blue-600 hover:bg-blue-700 text-white" disabled={isPending}>
          <Wallet className="w-5 h-5 mr-2" />
          {isPending ? "Connecting..." : "Connect Wallet"}
          <ChevronDown className="w-4 h-4 ml-2" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent className="w-full bg-blue-800 border-blue-600">
        {connectors.map((connector) => (
          <DropdownMenuItem
            key={connector.uid}
            onClick={() => {
              connect({ connector })
              setIsOpen(false)
            }}
            className="text-white hover:bg-blue-700 cursor-pointer"
          >
            <div className="flex items-center gap-2">
              {getConnectorIcon(connector.name)}
              {getConnectorDisplayName(connector.name)}
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
