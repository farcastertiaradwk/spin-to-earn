"use client"

import { useState, useEffect } from "react"
import { Flame } from "lucide-react"

interface SpinWheelProps {
  isSpinning: boolean
}

export function SpinWheel({ isSpinning }: SpinWheelProps) {
  const [rotation, setRotation] = useState(0)

  const prizes = [
    { label: "ZONK", color: "bg-red-500", weight: 60 },
    { label: "10 DEGEN", color: "bg-green-500", weight: 15 },
    { label: "ZONK", color: "bg-red-500", weight: 60 },
    { label: "50 Points", color: "bg-blue-500", weight: 20 },
    { label: "ZONK", color: "bg-red-500", weight: 60 },
    { label: "25 DEGEN", color: "bg-green-600", weight: 8 },
    { label: "ZONK", color: "bg-red-500", weight: 60 },
    { label: "100 Points", color: "bg-purple-500", weight: 12 },
  ]

  useEffect(() => {
    if (isSpinning) {
      const spins = 5 + Math.random() * 5 // 5-10 full rotations
      const finalRotation = rotation + spins * 360 + Math.random() * 360
      setRotation(finalRotation)
    }
  }, [isSpinning, rotation])

  return (
    <div className="flex flex-col items-center">
      <div className="relative w-64 h-64">
        {/* Wheel */}
        <div
          className={`w-full h-full rounded-full border-4 border-blue-300 relative overflow-hidden transition-transform duration-3000 ease-out ${
            isSpinning ? "animate-spin" : ""
          }`}
          style={{
            transform: `rotate(${rotation}deg)`,
            transitionDuration: isSpinning ? "3s" : "0s",
          }}
        >
          {prizes.map((prize, index) => (
            <div
              key={index}
              className={`absolute w-full h-full ${prize.color}`}
              style={{
                clipPath: `polygon(50% 50%, ${50 + 40 * Math.cos(((index * 45 - 22.5) * Math.PI) / 180)}% ${50 + 40 * Math.sin(((index * 45 - 22.5) * Math.PI) / 180)}%, ${50 + 40 * Math.cos((((index + 1) * 45 - 22.5) * Math.PI) / 180)}% ${50 + 40 * Math.sin((((index + 1) * 45 - 22.5) * Math.PI) / 180)}%)`,
                transform: `rotate(${index * 45}deg)`,
              }}
            >
              <div
                className="absolute text-white font-bold text-xs"
                style={{
                  top: "20%",
                  left: "50%",
                  transform: "translate(-50%, -50%) rotate(-45deg)",
                  transformOrigin: "center",
                }}
              >
                {prize.label}
              </div>
            </div>
          ))}
        </div>

        {/* Center Hub */}
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-blue-600 rounded-full border-4 border-white flex items-center justify-center">
          <Flame className="w-6 h-6 text-blue-200" />
        </div>

        {/* Pointer */}
        <div className="absolute top-0 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
          <div className="w-0 h-0 border-l-4 border-r-4 border-b-8 border-l-transparent border-r-transparent border-b-yellow-400"></div>
        </div>
      </div>
    </div>
  )
}
