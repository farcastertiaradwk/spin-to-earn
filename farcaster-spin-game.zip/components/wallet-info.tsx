"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Shield, Zap } from "lucide-react"

export function WalletInfo() {
  return (
    <Card className="bg-blue-800/50 border-blue-400 backdrop-blur-sm">
      <CardContent className="pt-6">
        <div className="text-center space-y-4">
          <h3 className="text-white font-semibold text-lg">Supported Wallets</h3>

          <div className="grid grid-cols-2 gap-4">
            <div className="bg-blue-700/50 rounded-lg p-4 border border-blue-500">
              <div className="flex flex-col items-center gap-2">
                <div className="text-2xl">🦊</div>
                <span className="text-white font-medium">MetaMask</span>
                <Badge variant="secondary" className="bg-green-600 text-green-100 text-xs">
                  Browser Extension
                </Badge>
              </div>
            </div>

            <div className="bg-blue-700/50 rounded-lg p-4 border border-blue-500">
              <div className="flex flex-col items-center gap-2">
                <div className="text-2xl">🔵</div>
                <span className="text-white font-medium">Coinbase</span>
                <Badge variant="secondary" className="bg-blue-600 text-blue-100 text-xs">
                  Mobile & Web
                </Badge>
              </div>
            </div>
          </div>

          <div className="space-y-2 text-blue-200 text-sm">
            <div className="flex items-center gap-2 justify-center">
              <Shield className="w-4 h-4" />
              <span>Secure Web3 Connection</span>
            </div>
            <div className="flex items-center gap-2 justify-center">
              <Zap className="w-4 h-4" />
              <span>Base Network Optimized</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
