import { createConfig, http } from "wagmi"
import { base, baseSepolia } from "wagmi/chains"
import { coinbaseWallet, injected } from "wagmi/connectors"

export const wagmiConfig = createConfig({
  chains: [base, baseSepolia],
  connectors: [
    injected(),
    coinbaseWallet({
      appName: "DEGEN Spin Game",
      appLogoUrl: "https://your-domain.vercel.app/icon.png",
    }),
  ],
  transports: {
    [base.id]: http(),
    [baseSepolia.id]: http(),
  },
})

// DEGEN token contract address on Base
export const DEGEN_CONTRACT_ADDRESS = "0x4ed4E862860beD51a9570b96d89aF5E1B0Efefed"

// Your recipient wallet
export const RECIPIENT_WALLET = "0xCC5552a28C2AA0AaE2B09826311900b466AebA65"
